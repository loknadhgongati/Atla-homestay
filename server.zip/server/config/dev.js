// Remove this file and add your own "dev.js" file
// See lectures for more info

module.exports = {
  DB_URI: 'mongodb+srv://gongatiloknadh:8Hp0EskY0bR4cR15@cluster0.okedt.mongodb.net/api?retryWrites=true&w=majority'
};
